<template>
  <card-info-fields></card-info-fields>
</template>

<script>
import CardInfoFields from './components/CardInfoFields.vue'
export default {
  name: 'App',
  components: {
    CardInfoFields
  }
}
</script>

<style>
</style>
