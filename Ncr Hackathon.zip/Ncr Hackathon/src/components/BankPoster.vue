<template>
    <div class="container">
        <h1>{{ heading }}</h1>
        <p>{{ description }}</p>
    </div>
</template>
<script>
export default {
    props: ['heading', 'description', 'image', 'bgcolor'],
    data() {

    }
}
</script>
<style scoped>
.container {
    width: 300px;
    height: 300px;
    background-color: v-bind('bgcolor');
}
</style>