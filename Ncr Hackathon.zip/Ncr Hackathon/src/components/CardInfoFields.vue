<template>
    <div class="container">
        <base-input ref="heading" name="heading" placeholder="Enter Heading" type="text"/>
        <base-input ref="description" name="description" placeholder="Enter Description" type="text"/>
        <base-input ref="image" name="image" placeholder="Enter Image URL" type="text"/>
        <base-input ref="bgcolor" name="bgcolor" placeholder="Enter Background Color" />
        <base-button @click="onGenerate">Generate</base-button>
    </div>
    <div class="container" id="poster" >
        <bank-poster v-if="isPosterGenerated" :heading="heading" :description="description" :image="image" :bgcolor="bgcolor"></bank-poster>
        <h1 v-else>Generate the Poster</h1>
    </div>
    <div class="container" id="preview">
        <h1>PREVIEW:</h1>
    </div>
    <div class="container">
        <base-check-button>
            <div class="check_container">
                <input ref="linkedin" name="toLinkedIn" placeholder="Post to LinkedIn" type="checkbox"/>
                <span>Post to LinkedIn</span>
            </div>
            <div class="check_container">
                <input ref="twitter" name="toTwitter" placeholder="Post to Twitter" type="checkbox"/>
                <span>Post to Twitter</span>
            </div>
        </base-check-button>
        <base-button @click="onClick">Submit</base-button>
    </div>
</template>

<script>
import BaseInput from './UI/BaseInput.vue'
import BaseButton from './UI/BaseButton.vue'
import BaseCheckButton from './UI/BaseCheckButton.vue'
import BankPoster from './BankPoster.vue'
import axios from 'axios'
import domtoimage from 'dom-to-image';
export default {
    components: {
        BaseInput,
        BaseButton,
        BaseCheckButton,
        BankPoster
    },
    data() {
        return {
            name: 'CardInfoFields',
            access_token: 'AQXFlC_Md_Whj6LbCGqM9C4niZXNkBZk2y7f12XEN9xeUxZIbT9qXAsHynx3L6LzTP0xAcB4CKzxIaiM9cSNugezfyua9kHAwCbUY9fXcx9v_aMc1ucUM1yIPjallK1xGc4mAm0w5gRC56eiUV-QqpQmUWwXXeJ7U0L0ZXtMDFVkh8UmbztnxAQsVAIdWx_jDJtZb3DR1ut0AvIUKCjrLX0DoSN_FoxfyYVkMWs_2OIdkjjYGUxmJ4qOtV6yyq9GOt-WTonBQyVE6Pv2cMioXErcWBet6vwjnkBlHhr0ShsNbtVwyvmBtK4GjuqMuB_xkHKgqCITYv4OZEshgdctlpPcqd61kw',
            isPosterGenerated: false,
            heading: "",
            description: "",
            image: "",
            bgcolor: "",
            imageToRender: null,
            imageFile: null,
        }
    },
    methods: {
        onClick() {
            const linkedinStatus = this.$refs.linkedin.checked;
            // const twitterStatus = this.$refs.twitter.checked;
            if(linkedinStatus) {
                console.log(this.imageFile);
                let formData = new FormData();
                formData.append('heading', this.heading);
                formData.append('description', this.description);
                formData.append('image', this.imageToRender);
                formData.append('file', this.imageFile);
                axios.post("http://localhost:8000/post/", formData) 
                .then(res => {
                    console.log(res)
                })
                .catch(err => {
                    console.log(err)
                })
            }
        },
        onGenerate() {
            const heading = this.$refs.heading.$el.querySelector('input').value;
            const description = this.$refs.description.$el.querySelector('input').value;
            const image = this.$refs.image.$el.querySelector('input').value;
            const bgcolor = this.$refs.bgcolor.$el.querySelector('input').value;
            this.heading = heading;
            this.description = description;
            this.image = image;
            this.bgcolor = bgcolor;
            this.isPosterGenerated = true;

            let poster = document.getElementById('poster');
            let preview = document.getElementById('preview');
            console.log("POSTER - " + poster);
            domtoimage.toPng(poster)
            .then(dataUrl => {


                let src = dataUrl.slice(22);
                const byteCharacters = atob(src);
                const byteNumbers = new Array(byteCharacters.length);
                for (let i = 0; i < byteCharacters.length; i++) {
                    byteNumbers[i] = byteCharacters.charCodeAt(i);
                }
                const byteArray = new Uint8Array(byteNumbers);
                const blob = new Blob([byteArray], {type: 'image/gif'});
                var imageUrl = URL.createObjectURL(blob);
                // document.querySelector("#image").src = imageUrl;
                // console.log(imageUrl)

                var img = new Image();
                img.src = imageUrl;
                preview.appendChild(img);
                this.imageToRender = imageUrl;
                this.imageFile = new File([blob], "image.png", {type: "image/png"});
                console.log(this.imageFile);
                // fetch(imageUrl)
                //     .then(response => response.blob())
                //     .then(blob => {
                //         this.imageFile = blob;
                //         console.log(blob);
                //     })
                //     .catch(error => {
                //         console.error('Error fetching or processing the file:', error);
                //     });
            })
            .catch(error => {
                console.error('oops, something went wrong!', error);
            });
        }
    }
}
</script>

<style scoped>
.container {
    border: 1px solid #ccc;
    padding: 10px;
    margin: 10px;
    display: flex;
    flex-direction: column;
    align-items: center;
    /* align-items: flex-start; */
}
.check_container {
    margin: 10px;
}
</style>