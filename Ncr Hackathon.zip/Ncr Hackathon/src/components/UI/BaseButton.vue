<template>
    <button class="btn">
        <slot></slot>
    </button>
</template>
<script>

</script>
<style scoped>
.btn {
    margin: 10px;
    padding: 5px;
    background-color: white;
    color: black;
    border: 2px solid black;
    border-radius: 5px;
}
.btn:hover {
    background-color: black;
    color: white;
    cursor: pointer;
}
</style>