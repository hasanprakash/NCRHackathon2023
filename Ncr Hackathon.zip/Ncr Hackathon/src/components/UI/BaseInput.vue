<template>
    <div class="input_container">
        <input :name="name" :placeholder="placeholder" :type="type"/>
    </div>
</template>
<script>
export default {
    props: ['name', 'placeholder', 'type']
}

</script>
<style scoped>
.input_container {
    border: 2px solid black;
    margin: 10px;
    border-radius: 5px;;
}
.input_container input {
    border: none;
    padding: 10px;
}
</style>