<template>
 <div class="check">
    <slot></slot>
 </div>
</template>
<script>

</script>
<style scoped>
.check {
   width: 180px;
   display: flex;
   flex-direction: column;
   align-items: center;
   border-radius: 5px;
   margin: 10px;
}
</style>